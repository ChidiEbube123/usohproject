package com.example.demo.controller;

import com.example.demo.model.Book;
import com.example.demo.service.BookService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/")
public class BooksController {
    @Autowired
    private BookService bookService;
    @GetMapping("/")
    public String getAllBook(Model model, @RequestParam(defaultValue = "0") int page,
                             @RequestParam(defaultValue = "2") int size){
        Page<Book> books = bookService.getPagination(page, size);
        model.addAttribute("books", books);
        return "index";

    }
    @GetMapping("/createbook")
    public  String createBook(Model model){
        model.addAttribute("book", new Book());
        return "createbook";
    }
    @PostMapping("/admin/add")
    public  String submitBook(Model model, @ModelAttribute Book book){
        bookService.createBook(book);
        model.addAttribute("books", bookService.getAllBook());
        return  "redirect:/user/admin";
    }
    @GetMapping("/view/{id}")
    public  String viewBook(Model model, @PathVariable Integer id){
        model.addAttribute("book", bookService.getBook(id));
        return  "book-details";
    }
    @GetMapping("/editbook/{id}")
    public  String editBook(Model model, @PathVariable Integer id){
        model.addAttribute("book", bookService.getBook(id));
        return  "edit";
    }
    @PostMapping("/editbook")
    public String edit(@Valid @ModelAttribute("user") Book book, BindingResult result, Model model, HttpServletRequest request){

        bookService.save(book);
        return "redirect:/";}
    @GetMapping("/delete/{id}")
    public  String deleteBook( @PathVariable Integer id){
        bookService.deleteBook(id);
        return  "redirect:/";
    }
    @GetMapping
    public ResponseEntity<Page<User>> getAllUsers(Pageable pageable) {
        Page<User> users = userService.getUsers(pageable);
        return ResponseEntity.ok(users);
    }
}


